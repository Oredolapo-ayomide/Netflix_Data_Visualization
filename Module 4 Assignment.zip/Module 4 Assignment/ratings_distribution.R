# Install ggplot2 if not already installed
# install.packages("ggplot2")

library(ggplot2)

# Set working directory
setwd("C:/Users/AyomideOgunsiji/OneDrive - VFD Group/Assignments/Module 4 Assignment")

# Read the cleaned CSV file
df <- read.csv("Netflix_shows_movies_cleaned.csv", stringsAsFactors = FALSE)

# Count how many titles fall into each rating
rating_counts <- as.data.frame(table(df$rating))

# Rename columns for clarity
colnames(rating_counts) <- c("Rating", "Count")

# Sort ratings by count in descending order
rating_counts <- rating_counts[order(-rating_counts$Count), ]

# Create the bar plot
ggplot(rating_counts, aes(x = Rating, y = Count, fill = Rating)) +
  geom_bar(stat = "identity") +
  theme_minimal() +
  labs(title = "Distribution of Ratings on Netflix",
       x = "Rating",
       y = "Number of Titles") +
  theme(axis.text.x = element_text(angle = 45, hjust = 1)) +
  guides(fill = "none")  # New syntax to remove legend
